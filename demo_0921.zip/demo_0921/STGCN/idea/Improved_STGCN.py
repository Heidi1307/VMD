import math
import torch
import torch.nn as nn
import torch.nn.functional as F

from STGCN.idea.DeformConv2d import DeformConv2d

'''模块结构
DeformTimeBlock: 替换了传统的时间卷积结构，使用了可变形卷积来捕捉时序数据的动态特征。
STGCNBlock: 包含了一个DeformTimeBlock和图卷积操作，通过邻接矩阵来处理时空图数据。
STGCN: 整体网络结构，连接了多个STGCNBlock，并添加了一个全连接层来生成最终的输出。'''
'''
# 传统卷积层
class TimeBlock(nn.Module):
    """
    Neural network block that applies a temporal convolution to each node of
    a graph in isolation.
    神经网络块，对孤立的图的每个节点应用时间卷积。
    """

    def __init__(self, in_channels, out_channels, kernel_size=3):
        """
        :param in_channels: Number of input features at each node in each time
        step.
        :param out_channels: Desired number of output channels at each node in
        each time step.
        :param kernel_size: Size of the 1D temporal kernel.
        """
        super(TimeBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv2 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))
        self.conv3 = nn.Conv2d(in_channels, out_channels, (1, kernel_size))

    def forward(self, X):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels)
        :return: Output data of shape (batch_size, num_nodes,
        num_timesteps_out, num_features_out=out_channels)
        """
        # Convert into NCHW format for pytorch to perform convolutions.
        X = X.permute(0, 3, 1, 2)
        temp = self.conv1(X) + torch.sigmoid(self.conv2(X))
        out = F.relu(temp + self.conv3(X))
        # Convert back from NCHW to NHWC
        out = out.permute(0, 2, 3, 1)
        return out
'''

class DeformTimeBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3):
        super(DeformTimeBlock, self).__init__()
        # 使用可变形卷积替代传统卷积
        self.conv1 = DeformConv2d(in_channels, out_channels, kernel_size=(1, kernel_size))  # 保持这个参数
        self.conv2 = DeformConv2d(in_channels, out_channels, kernel_size=(1, kernel_size))
        self.conv3 = DeformConv2d(in_channels, out_channels, kernel_size=(1, kernel_size))

    def forward(self, X):
        # Convert into NCHW format for pytorch to perform convolutions.
        X = X.permute(0, 3, 1, 2)  # (batch_size, num_features, num_nodes, num_timesteps)
        temp = self.conv1(X) + torch.sigmoid(self.conv2(X))
        out = F.relu(temp + self.conv3(X))
        # Convert back from NCHW to NHWC
        out = out.permute(0, 2, 3, 1)  # (batch_size, num_nodes, num_timesteps_out, num_features_out)
        return out

class STGCNBlock(nn.Module):
    """
    Neural network block that applies a temporal convolution on each node in
    isolation, followed by a graph convolution, followed by another temporal
    convolution on each node.
    神经网络块，在每个节点上单独应用时间卷积，然后是图卷积，然后是每个节点上的另一个时间卷积。
    """

    def __init__(self, in_channels, spatial_channels, out_channels,
                 num_nodes):
        """
        :param in_channels: Number of input features at each node in each time
        step.每个时间步长中每个节点的输入特征数。
        :param spatial_channels: Number of output channels of the graph
        convolutional, spatial sub-block.输出通道数的图形卷积，空间子块。
        :param out_channels: Desired number of output features at each node in
        each time step.在每个时间步长中每个节点所需的输出特征数。
        :param num_nodes: Number of nodes in the graph.图中的节点数。
        """
        super(STGCNBlock, self).__init__()
        self.temporal1 = DeformTimeBlock(in_channels=in_channels,
                                   out_channels=out_channels)
        self.Theta1 = nn.Parameter(torch.FloatTensor(out_channels,
                                                     spatial_channels))
        self.temporal2 = DeformTimeBlock(in_channels=spatial_channels,
                                   out_channels=out_channels)
        self.batch_norm = nn.BatchNorm2d(num_nodes)
        self.dropout = nn.Dropout(0.5)  # 在每个STGCNBlock中添加dropout层,以降低过拟合的风险。
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.Theta1)
        # reset_parameters()方法使用了正态分布来初始化Theta1参数。可以考虑其他初始化方法，
        # 如nn.init.xavier_uniform_，以提高模型的收敛速度。
        '''stdv = 1. / math.sqrt(self.Theta1.shape[1])
        self.Theta1.data.uniform_(-stdv, stdv)'''

    def forward(self, X, A_hat):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels).
        :param A_hat: Normalized adjacency matrix.归一化邻接矩阵。
        :return: Output data of shape (batch_size, num_nodes,
        num_timesteps_out, num_features=out_channels).
        """
        t = self.temporal1(X)
        lfs = torch.einsum("ij,jklm->kilm", [A_hat, t.permute(1, 0, 2, 3)])
        # t2 = F.relu(torch.einsum("ijkl,lp->ijkp", [lfs, self.Theta1]))
        t2 = F.relu(torch.matmul(lfs, self.Theta1))
        t3 = self.temporal2(t2)
        return self.batch_norm(self.dropout(t3))  # 在这里应用dropout
        # return t3


class STGCN(nn.Module):
    """
    Spatio-temporal graph convolutional network as described in
    https://arxiv.org/abs/1709.04875v3 by Yu et al.
    Input should have shape (batch_size, num_nodes, num_input_time_steps,
    num_features).
    Yu等人描述的时空图卷积网络。输入应该具有形状(batch_size, num_nodes, num_input_time_steps, num_features)。
    """

    def __init__(self, num_nodes, num_features, num_timesteps_input,
                 num_timesteps_output):
        """
        :param num_nodes: Number of nodes in the graph.图中的节点数。
        :param num_features: Number of features at each node in each time step.每个时间步长中每个节点上的特征数。
        :param num_timesteps_input: Number of past time steps fed into the network.输入网络的过去时间步长数。
        :param num_timesteps_output: Desired number of future time steps output by the network.期望网络输出的未来时间步长数。
        """
        super(STGCN, self).__init__()
        self.block1 = STGCNBlock(in_channels=num_features, spatial_channels=16, out_channels=64, num_nodes=num_nodes)
        self.block2 = STGCNBlock(in_channels=64, spatial_channels=16, out_channels=64, num_nodes=num_nodes)
        self.last_temporal = STGCNBlock(in_channels=64, spatial_channels=16, out_channels=64, num_nodes=num_nodes)
        self.fully = nn.Linear((num_timesteps_input - 2 * 5) * 64, num_timesteps_output)

    def forward(self, A_hat, X):
        """
        :param X: Input data of shape (batch_size, num_nodes, num_timesteps,
        num_features=in_channels).
        :param A_hat: Normalized adjacency matrix.归一化邻接矩阵。
        """
        out1 = self.block1(X, A_hat)
        out2 = self.block2(out1, A_hat)
        out3 = self.last_temporal(out2,A_hat)
        out4 = self.fully(out3.reshape((out3.shape[0], out3.shape[1], -1)))
        return out4


