# 导入必要的库
import torch.optim as optim
from bayes_opt import BayesianOptimization
from torch_geometric.nn import GCNConv  # 这是图卷积层
import torch.nn as nn
from STGCN.idea import DeformConv2d


# 可变形卷积层
class STGCNWithDeformableConv(nn.Module):
    def __init__(self, num_nodes, in_channels, out_channels, kernel_size, num_layers, use_modulation=False):
        super(STGCNWithDeformableConv, self).__init__()
        self.layers = nn.ModuleList()
        for _ in range(num_layers):
            self.layers.append(
                DeformConv2d(in_channels, out_channels, kernel_size=kernel_size, modulation=use_modulation))
        self.gcn = GCNConv(out_channels, out_channels)  # 图卷积层

    def forward(self, x, edge_index):
        for layer in self.layers:
            x = layer(x)
        x = self.gcn(x, edge_index)
        return x


# STGCN模型的定义
class STGCNModel(nn.Module):
    def __init__(self, num_nodes, in_channels, out_channels, kernel_size, num_layers):
        super(STGCNModel, self).__init__()
        self.layers = nn.ModuleList()
        # 构建多个可变形卷积层
        for _ in range(num_layers):
            self.layers.append(DeformableConvLayer(in_channels, out_channels, kernel_size))

        # 图卷积层
        self.gcn = GCNConv(out_channels, out_channels)

    def forward(self, x, edge_index):
        for layer in self.layers:
            x = layer(x)
        x = self.gcn(x, edge_index)
        return x


# 定义贝叶斯优化目标函数
def stgcn_train_evaluate(num_layers, learning_rate, kernel_size):
    # 初始化模型，超参数由贝叶斯优化传入
    model = STGCNModel(num_nodes=10, in_channels=3, out_channels=16, kernel_size=int(kernel_size),
                       num_layers=int(num_layers))
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # 简化版训练与评估，真实实现时需要加入训练数据加载与验证集评价
    for epoch in range(10):
        # 模型训练过程（略）
        pass

    # 返回验证集的损失或准确率（假设为dummy）
    val_loss = 0.05  # 需替换为实际计算值
    return -val_loss  # 贝叶斯优化默认最小化


# 贝叶斯优化设置
optimizer = BayesianOptimization(
    f=stgcn_train_evaluate,
    pbounds={'num_layers': (1, 5), 'learning_rate': (0.001, 0.01), 'kernel_size': (3, 7)},
    verbose=2
)

optimizer.maximize(init_points=5, n_iter=10)
