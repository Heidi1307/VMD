import torch
import torch.nn as nn
import pandas as pd
import optuna
from STGCN.idea.Improved_STGCN import DeformTimeBlock  # 导入 DeformTimeBlock
from STGCN.idea.Improved_STGCN import STGCN

train_dataloader = pd.read_csv('/Data/ws_feature/1025015.csv') # 测试数据集
val_dataloader = pd.read_csv('/Data/ws_feature/1025016.csv')  # 验证数据集

# 定义模型参数
num_nodes = 1  # 假设的时间序列数量
num_features = 1  # ws10m 列作为唯一特征
num_timesteps_input = 10  # 换成您想要的时间步
num_timesteps_output = 1  # 换成您想要预测的未来步数

# 定义目标函数
def objective(trial):
    kernel_size = trial.suggest_int('kernel_size', 2, 5)
    spatial_channels = trial.suggest_int('spatial_channels', 16, 64)
    learning_rate = trial.suggest_loguniform('learning_rate', 1e-5, 1e-2)
    num_epochs = 10  # 可调节的训练轮次

    # 使用更新后的 STGCN 构建模型
    model = STGCN(num_nodes, num_features, num_timesteps_input, num_timesteps_output).cuda()

    # 替换模型中卷积参数，使用 DeformTimeBlock
    model.block1.temporal1 = DeformTimeBlock(in_channels=num_features, out_channels=64, kernel_size=kernel_size).cuda()
    model.block1.temporal2 = DeformTimeBlock(in_channels=64, out_channels=64, kernel_size=kernel_size).cuda()
    model.block2.temporal1 = DeformTimeBlock(in_channels=64, out_channels=64, kernel_size=kernel_size).cuda()
    model.block2.temporal2 = DeformTimeBlock(in_channels=64, out_channels=64, kernel_size=kernel_size).cuda()
    model.last_temporal.temporal1 = DeformTimeBlock(in_channels=64, out_channels=64, kernel_size=kernel_size).cuda()

    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.MSELoss()

    # 在验证集上训练和验证模型
    for epoch in range(num_epochs):
        model.train()
        for batch in train_dataloader:
            A_hat, X, y = batch
            A_hat, X, y = A_hat.cuda(), X.cuda(), y.cuda()

            optimizer.zero_grad()
            output = model(A_hat, X)
            loss = criterion(output, y)
            loss.backward()
            optimizer.step()

    # 评估模型
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for batch in val_dataloader:
            A_hat, X, y = batch
            A_hat, X, y = A_hat.cuda(), X.cuda(), y.cuda()
            output = model(A_hat, X)
            val_loss += criterion(output, y).item()

    return val_loss / len(val_dataloader)


# 运行优化
study = optuna.create_study(direction='minimize')
study.optimize(objective, n_trials=50)

# 打印最佳超参数
print("最佳试验：")
trial = study.best_trial
print("  最优值: {}".format(trial.value))
print("  参数:")
for key, value in trial.params.items():
    print("    {}: {}".format(key, value))