# train.py
import torch
from model import STGCNWithDeformableConv  # 从 model.py 导入模型
from bayes_opt import BayesianOptimization


def train_model(num_layers, kernel_size, learning_rate):
    # 初始化模型
    model = STGCNWithDeformableConv(num_nodes=10, in_channels=3, out_channels=16, kernel_size=int(kernel_size),
                                    num_layers=int(num_layers))
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # 加载数据和训练流程 (略)

    # 返回验证集损失
    val_loss = 0.05  # 这里是一个假设的验证集损失，实际代码应替换为计算值
    return -val_loss


def run_bayesian_optimization():
    optimizer = BayesianOptimization(
        f=train_model,
        pbounds={'num_layers': (1, 5), 'kernel_size': (3, 7), 'learning_rate': (0.001, 0.01)},
        verbose=2
    )
    optimizer.maximize(init_points=5, n_iter=10)


if __name__ == "__main__":
    run_bayesian_optimization()
