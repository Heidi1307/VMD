import numpy as np
import pandas as pd
import os
from vmdpy import VMD
from scipy.stats import skew, kurtosis


# 定义适应度函数（如果需要进行结果验证可以使用，但此处可以省略）
def fitness_function(signal, alpha, K, tau=0, DC=0, init=1, tol=1e-7):
    u, u_hat, omega = VMD(signal, alpha=alpha, tau=tau, K=K, DC=DC, init=init, tol=tol)
    reconstructed_signal = np.sum(u, axis=0)
    error = np.linalg.norm(signal - reconstructed_signal)
    return error

# 从信号中提取特征
def extract_features(imfs):
    features = []
    for imf in imfs:
        mean = np.mean(imf)
        std = np.std(imf)
        max_value = np.max(imf)
        min_value = np.min(imf)
        skewness = skew(imf)
        kurt = kurtosis(imf)

        features.append([mean, std, max_value, min_value, skewness, kurt])

    return np.array(features)

# 使用已知的最优参数
ALPHA_OPT = 211.43  # 已知优化参数 alpha
K_OPT = 7  # 已知优化参数 K


# 主程序
def main():
    data_dir = "C:/HeidiExp/projects/demo_0921/Data/ws_feature/"
    result_dir = "C:/HeidiExp/projects/demo_0921/Data/imf_features_7/"

    for filename in os.listdir(data_dir):
        if filename.endswith(".csv"):
            # 读取风电场数据
            farm_id = filename.split('.')[0]  # 获取风电场序号，例如 '1025015'
            data = pd.read_csv(os.path.join(data_dir, filename))

            # 提取风速数据
            signal = data['ws10m'].values

            # 使用VMD分解
            u, u_hat, omega = VMD(signal, alpha=ALPHA_OPT, K=K_OPT, tau=0, DC=0, init=1, tol=1e-7)

            # 提取IMF特征
            features = extract_features(u)

            # 结果处理，根据需要提取特征（例如模态均值、方差等）
            # 将IMF特征转为DataFrame
            feature_df = pd.DataFrame(features, columns=['mean', 'std', 'max', 'min', 'skewness', 'kurtosis'])

            # 保存节点特征到文件，例如使用CSV
            output_path = os.path.join(result_dir, f"{farm_id}_imf_features.csv")
            feature_df.to_csv(output_path, index=False)

if __name__ == "__main__":
    main()