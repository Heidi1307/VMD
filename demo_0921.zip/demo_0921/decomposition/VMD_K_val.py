import numpy as np
import pandas as pd
import os
from vmdpy import VMD
from scipy.stats import pearsonr
import time

# 定义均方误差适应度函数
def mse(signal, reconstructed_signal):
    return np.mean((signal - reconstructed_signal) ** 2)

# 定义皮尔逊相关系数适应度函数
def pearson_coefficient(signal, reconstructed_signal):
    return pearsonr(signal, reconstructed_signal)[0]

# 定义运行时间适应度函数
def execution_time(func, *args, **kwargs):
    start_time = time.time()
    result = func(*args, **kwargs)
    elapsed_time = time.time() - start_time
    return result, elapsed_time

# 主程序
def main():
    data_dir = "C:/HeidiExp/projects/Q2_tsf/Data/val_data/ws_feature_val/"
    result_dir = "C:/HeidiExp/projects/Q2_tsf/Data/val_data/val_result/"

    # 初始化结果列表
    results = []

    for filename in os.listdir(data_dir):
        if filename.endswith(".csv"):
            # 读取风电场数据
            farm_id = filename.split('.')[0]  # 获取风电场序号，例如 '1025015'
            data = pd.read_csv(os.path.join(data_dir, filename))

            # 提取风速数据
            signal = data['ws10m'].values

            for K in range(0, 8):  # K 从 0 到 7，VMD_PLO优化结果
                # 使用VMD分解并计算运行时间
                u, _, _ = execution_time(VMD, signal, alpha=211.43, K=K, tau=0, DC=0, init=1, tol=1e-7)
                # alpha 为VMD_PLO优化结果
                # 计算重构信号
                reconstructed_signal = np.sum(u, axis=0)

                # 计算适应度值
                mse_value = mse(signal, reconstructed_signal)
                pearson_value = pearson_coefficient(signal, reconstructed_signal)
                elapsed_time = execution_time(lambda: VMD(signal, alpha=211.43, K=K, tau=0, DC=0, init=1, tol=1e-7))[1]

                # 将结果保存到列表
                results.append({
                    'farm_id': farm_id,
                    'K': K,
                    'mse': mse_value,
                    'pearson': pearson_value,
                    'execution_time': elapsed_time
                })

    # 将结果转换为DataFrame并保存
    result_df = pd.DataFrame(results)
    output_path = os.path.join(result_dir, "K_val_result.csv")
    result_df.to_csv(output_path, index=False)

if __name__ == "__main__":
    main()