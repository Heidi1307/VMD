import matplotlib.pyplot as plt
import random  # 导入随机生成模块
import pandas as pd
from matplotlib import font_manager  # 导入字体管理模块
from pylab import mpl
# 设置显示中文字体
mpl.rcParams["font.sans-serif"] = ["SimHei"]
# 设置正常显示符号
mpl.rcParams["axes.unicode_minus"] = False

my_font = font_manager.FontProperties(fname="C:/WINDOWS/Fonts/STSONG.TTF")
# 定义中文字体属性，文字储存路径可以在C:/WINDOWS/Fonts/找到，本次设置为宋体

data = pd.read_csv('C:/HeidiExp/projects/demo_0921/Data/ws_feature/1025161.csv')

# 查看单个风电场的风速
x = data['dates_utc8']  # x值为0-120
y = data['ws10m']  # y值为120个在20-35之间的随机数


from vmdpy import VMD
# VMD 的一些参数
alpha = 211.43        # 适度的频带宽度约束(PLO_VMD结果)
tau = 0.            # 容忍噪声（没有严格的保真度要求）
K = 7               # 7个模态(PLO_VMD结果)
DC = 0              # 不强制直流分量
init = 1            # 均匀初始化角频率
tol = 1e-7

# 运行 VMD
u, u_hat, omega = VMD(data['ws10m'], alpha, tau, K, DC, init, tol)
# 可视化分解后的 7 个 IMF
plt.figure(figsize=(15, 8))

for i in range(K):
    plt.subplot(K, 1, i+1)
    plt.plot(u[i, :])
    plt.title(f'IMF {i+1}')
    plt.xlabel('时间')
    plt.ylabel('振幅')

plt.tight_layout()
plt.show()
# plt.savefig("C:/HeidiExp/projects/demo_0921/figures/vmd_to_IMF7_015farm.svg", dpi=600)
# 保存每个 IMF 到不同的 DataFrame
imf_dataframes = {}
for i in range(len(u)):
    imf_name = 'imf_{}'.format(i+1)
    imf_dataframes[imf_name] = pd.DataFrame({'Value': u[i]})

print(u.shape)  #(7.5808),表示 7 个 IMF 信号，每个 IMF 信号有 5808 个时间步
