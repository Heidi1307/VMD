import pandas as pd
import numpy as np

'''
计算风电场之间的地理距离，并构造加权邻接矩阵，其中两个风电场之间的连接权重为其距离的倒数。
'''

# 经纬度数据路径
loc_path = "C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\loc.csv"
location_data = pd.read_csv(loc_path)

# 根据地理距离创建加权邻接矩阵
def create_weighted_adjacency_matrix(location_data, threshold_distance=10):
    num_farms = len(location_data)
    weighted_adjacency_matrix = np.zeros((num_farms, num_farms))

    for i in range(num_farms):
        for j in range(i + 1, num_farms):
            # 计算两个风电场之间的距离
            lon1, lat1 = location_data.iloc[i][['longtitude', 'latitude']]
            lon2, lat2 = location_data.iloc[j][['longtitude', 'latitude']]
            distance = np.sqrt((lon1 - lon2) ** 2 + (lat1 - lat2) ** 2)

            if distance < threshold_distance:
                # 通过距离的倒数作为权重
                weighted_adjacency_matrix[i, j] = 1 / distance
                weighted_adjacency_matrix[j, i] = 1 / distance  # 对称矩阵

    return weighted_adjacency_matrix

# 生成加权邻接矩阵
weighted_adjacency_matrix = create_weighted_adjacency_matrix(location_data)

# 如果有需要，可以规范化加权邻接矩阵
def normalize_weighted_adjacency_matrix(weighted_adj_matrix):
    D = np.sum(weighted_adj_matrix, axis=1)
    D_inv = np.diag(1.0 / D)  # 计算D的逆矩阵
    W_hat = np.dot(D_inv, weighted_adj_matrix)  # 计算规范化加权邻接矩阵
    return W_hat

W_hat = normalize_weighted_adjacency_matrix(weighted_adjacency_matrix)

# 将加权邻接矩阵转换为 DataFrame 并保存为 CSV 文件
weighted_adjacency_df = pd.DataFrame(weighted_adjacency_matrix)

# 保存为 CSV 文件
weighted_adjacency_df.to_csv('C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\weighted_adjacency_matrix.csv', index=False, header=False)

print("加权邻接矩阵已保存为 CSV 文件。")