import pandas as pd
import numpy as np
import torch

# Step 1: 读取加权邻接矩阵和节点特征矩阵
weighted_adjacency_matrix_path = 'C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\weighted_adjacency_matrix.csv'
node_features_path = 'C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\node_features.csv'

# 加载加权邻接矩阵和节点特征矩阵
weighted_adjacency_matrix = pd.read_csv(weighted_adjacency_matrix_path, header=None).values
node_features_matrix = pd.read_csv(node_features_path).values  # 假定这里包含时间序列特征

# Step 2: 构造属性图
# 将weighted adjacency matrix转化为torch tensor
W_hat_tensor = torch.FloatTensor(weighted_adjacency_matrix)

# 将节点特征矩阵转化为torch tensor
node_features_tensor = torch.FloatTensor(node_features_matrix)

# Step 3: 构造时空图结构
# 假设我们有timesteps，可以将节点特征纵向堆叠来构造时空图
timesteps = node_features_tensor.shape[0]  # 取特征矩阵的第一维(行数)表示时间步数
num_nodes = node_features_tensor.shape[1]  # 取特征矩阵的第二维（列数）表示节点数

print(timesteps, num_nodes)

# 时空图可以表示为 (batch_size, num_nodes, timesteps, feature_dim)
# 假设feature_dim为特征的列数
feature_dim = node_features_tensor.shape[2] if len(node_features_tensor.shape) == 3 else 1
# 增加一个维度以适应时空图模型
temporal_graph = node_features_tensor.view(1, timesteps, num_nodes, feature_dim)

# 输出时空图和关联矩阵
print("Weighted Adjacency Matrix Shape: ", W_hat_tensor.shape)  # 加权邻接矩阵
print("Node Features Shape: ", node_features_tensor.shape)      # 节点特征矩阵
print("Temporal Graph Shape: ", temporal_graph.shape)

# 你可以根据需要进一步处理这个时空图, 比如给它加上额外的时间信息、图结构信息等。

