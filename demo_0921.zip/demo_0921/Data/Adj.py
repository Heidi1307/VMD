import pandas as pd
import glob
from STGCN.idea.Improved_STGCN import STGCN  # 导入STGCN模型

# 步骤：生成邻接矩阵

# 经纬度数据路径
loc_path = "C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\loc.csv"
location_data = pd.read_csv(loc_path)

# 创建邻接矩阵
import numpy as np

# 根据地理距离
def create_adjacency_matrix(location_data, threshold_distance=10):
    num_farms = len(location_data)
    adjacency_matrix = np.zeros((num_farms, num_farms))

    for i in range(num_farms):
        for j in range(i + 1, num_farms):
            # 计算两个风电场之间的距离
            lon1, lat1 = location_data.iloc[i][['longtitude', 'latitude']]
            lon2, lat2 = location_data.iloc[j][['longtitude', 'latitude']]
            distance = np.sqrt((lon1 - lon2) ** 2 + (lat1 - lat2) ** 2)

            if distance < threshold_distance:
                adjacency_matrix[i, j] = 1
                adjacency_matrix[j, i] = 1  # 对称矩阵

    return adjacency_matrix


adjacency_matrix = create_adjacency_matrix(location_data)

# 正规化邻接矩阵
def normalize_adjacency_matrix(adj_matrix):
    D = np.sum(adj_matrix, axis=1)
    D_inv = np.diag(1.0 / D)  # 计算D的逆矩阵
    A_hat = np.dot(D_inv, adj_matrix)  # 计算规范化邻接矩阵
    return A_hat

A_hat = normalize_adjacency_matrix(adjacency_matrix)

print(adjacency_matrix)

# 存储为npy
#np.save('C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\adjacency_matrix.npy', adjacency_matrix)
# 存储为csv
# 将邻接矩阵转换为 DataFrame 并保存为 CSV 文件
adjacency_df = pd.DataFrame(adjacency_matrix)

# 保存为 CSV 文件
adjacency_df.to_csv('C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\adjacency_matrix.csv', index=False, header=False)
