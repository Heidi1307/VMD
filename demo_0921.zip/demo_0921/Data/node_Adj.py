import pandas as pd
import numpy as np
import glob

'''
读取多个 IMF （风速）特征文件，从每个文件中提取特征（均值、标准差、最大值、最小值、偏度、峰度）.
使用读取的IMF特征生成并输出一个节点特征矩阵。
节点特征矩阵，提供了每个风电场风速的统计特征
'''

# 功能函数：读取IMF特征数据
def read_imf_features(imf_path):
    imf_files = glob.glob(imf_path + "\\*_imf_features.csv")
    imf_features_list = []

    for file in imf_files:
        # 读取IMF特征文件
        imf_data = pd.read_csv(file)
        imf_features = [
            imf_data["mean"].values[0],
            imf_data["std"].values[0],
            imf_data["max"].values[0],
            imf_data["min"].values[0],
            imf_data["skewness"].values[0],
            imf_data["kurtosis"].values[0]
        ]
        imf_features_list.append(imf_features)

    return np.array(imf_features_list)


# 读取 IMFs 特征和生成节点特征矩阵
imf_path = "C:\\HeidiExp\\projects\\demo_0921\\Data\\imf_features_7"
node_features = read_imf_features(imf_path)

# 输出节点特征矩阵
print("节点特征矩阵：")
print(node_features)
# 存储为npy
# np.save('C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\node_features.npy', node_features)
#存储为csv
pd.DataFrame(node_features, columns=["mean", "std", "max", "min", "skewness", "kurtosis"]).to_csv('C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\node_features.csv', index=False)