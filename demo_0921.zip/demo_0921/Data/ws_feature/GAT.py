'''
图注意力网络（Graph Attention Network, GAT）来优化时间步和空间图形特征是一个有效的方法，
特别是在处理与节点之间的关系和影响相关性的信息时。
GAT通过在节点的邻居上应用注意力机制，从而能够对邻居节点的重要性进行加权，因此在图数据上进行预测时具有很大的灵活性。

下面是如何在时间序列预测中使用GAT来优化时间步的示例步骤：
1、准备数据：确保您有合适的节点特征矩阵和加权邻接矩阵。
2、定义GAT模型：构建GAT模型以处理节点特征和图连接结构。
3、集成时间信息：引入时间步信息以优化模型的输入结构。
4、训练和评估模型：通过训练模型并在验证集上评估其性能。
'''

import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import numpy as np

# Step 1: 读取数据
weighted_adjacency_matrix_path = 'C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\weighted_adjacency_matrix.csv'
node_features_path = 'C:\\HeidiExp\\projects\\demo_0921\\Data\\sum\\node_features.csv'

# 加载数据
W_hat = pd.read_csv(weighted_adjacency_matrix_path, header=None).values
X = pd.read_csv(node_features_path).values  # 假定这个表格是多时间步的节点特征


# Step 2: 定义GAT模型
class GATLayer(nn.Module):
    def __init__(self, input_dim, output_dim, dropout=0.6):
        super(GATLayer, self).__init__()
        self.attention = nn.MultiheadAttention(embed_dim=output_dim, num_heads=1, dropout=dropout)
        self.linear = nn.Linear(input_dim, output_dim)

    def forward(self, x, adj):
        x = self.linear(x)  # 线性变换
        x, _ = self.attention(x, x, x)  # 计算注意力权重
        return x


class GAT(nn.Module):
    def __init__(self, input_dim, output_dim, num_timesteps):
        super(GAT, self).__init__()
        self.layers = nn.ModuleList([GATLayer(input_dim, output_dim) for _ in range(num_timesteps)])

    def forward(self, x, adj):
        # x的形状应该是 (num_timesteps, num_nodes, input_dim)
        for layer in self.layers:
            x = layer(x, adj)  # 为每个时间步执行GAT
        return x


# Step 3: 准备输入数据
num_timesteps = X.shape[0]
num_nodes = X.shape[1]
feature_dim = X.shape[2] if len(X.shape) == 3 else 1

# 重塑输入以适应GAT模型
X_tensor = torch.FloatTensor(X).view(num_timesteps, num_nodes, feature_dim)
W_hat_tensor = torch.FloatTensor(W_hat)

# Step 4: 训练模型
# 实例化GAT模型
input_dim = feature_dim # 从输入特征维度获取
output_dim = 64  # GAT层输出的特征维度
num_epochs = 100
learning_rate = 0.001

model = GAT(input_dim, output_dim, num_timesteps)
criterion = nn.MSELoss()  # 选择适当的损失函数，MSE
optimizer = optim.Adam(model.parameters(), lr=learning_rate)  # 优化器，Adam

# 模型训练逻辑
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()

    # 前向传播
    output = model(X_tensor, W_hat_tensor)  # X_tensor 作为输入，W_hat_tensor 作为加权邻接矩阵

    # 假设您具有相应的目标
    target = ...  # 目标值根据时步准备
    loss = criterion(output, target)

    loss.backward()
    optimizer.step()

    # 输出当前 epoch 和损失
    if (epoch + 1) % 10 == 0:
        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')


    # print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {loss.item():.4f}')