# timestamp process,统一存为 ‘dates_utc8’

import os
import pandas as pd
import datetime

# 文件夹路径
folder_path = 'NWP/'
save_path = 'Data/NWP_feature/'


# 转换函数，处理小数部分以提高精度，并添加8小时
def convert_timestamp_to_utc8(ts):
    utc_datetime = datetime.datetime.fromordinal(int(ts)) + datetime.timedelta(days=ts % 1) - datetime.timedelta(
        days=366)
    # 将时间转换为UTC+8时间
    utc8_datetime = utc_datetime + datetime.timedelta(hours=8)
    return utc8_datetime


# 遍历文件夹中的所有CSV文件
for file_name in os.listdir(folder_path):
    if file_name.endswith('.csv'):
        file_path = os.path.join(folder_path, file_name)

        # 读取CSV文件
        df = pd.read_csv(file_path)

        # 检查是否有'sc_time_o'列
        if 'pre_time_o' in df.columns:
            # 处理时间戳并转换为UTC+8
            df['dates_utc8'] = df['pre_time_o'].apply(convert_timestamp_to_utc8)

            # 另存为新文件，文件名加上前缀converted_
            new_file_path = os.path.join(save_path, f'{file_name}')
            df.to_csv(new_file_path, index=False)

print("文件转换完成并另存为新文件。")
