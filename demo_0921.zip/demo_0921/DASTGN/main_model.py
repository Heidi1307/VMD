from coarse_module import *
from fine_module import *

'''
Spatio-Temporal GNN (STGNN)
这是一个时空图神经网络 (STGNN) 的实现，由两个主要模块 GConv 和 STGAT 组成。
'''


class GConv(nn.Module):
    '''
    图卷积层，用于处理时空图数据，集成历史特征和时空加权特征。
    '''

    def __init__(self, D_temporal, A_temporal, tot_nodes, tw, fw):
        super(GConv, self).__init__()
        # 总节点数
        self.tot_nodes = tot_nodes
        # 计算时空平滑矩阵
        self.sp_temp = torch.mm(D_temporal, torch.mm(A_temporal, D_temporal))

        # 历史特征权重和最终权重
        self.his_temporal_weight = tw
        self.his_final_weight = fw

    def forward(self, his_raw_features):
        '''
        前向传播，接收历史特征并输出更新后的特征。
        his_raw_features: 输入的历史特征，维度为 (batch_size, features)。
        '''

        # 保存自引用特征
        his_self = his_raw_features

        # 进行时空特征加权
        his_temporal = self.his_temporal_weight.repeat(self.tot_nodes, 1) * his_raw_features
        # 计算时空特征的加权矩阵
        his_temporal = torch.mm(self.sp_temp, his_temporal)

        # 合并自引用特征和时空加权特征
        his_combined = torch.cat([his_self, his_temporal], dim=1)
        # 应用ReLU激活函数并输出更新后的特征
        his_raw_features = torch.relu(his_combined.mm(self.his_final_weight))

        return his_raw_features


class STGAT(nn.Module):
    '''
    时空图注意力网络模型 (Spatial-Temporal Graph Attention Network)
    该模型通过多个图卷积层构建，同时引入干预变量和时间衰减。
    '''

    def __init__(self, input_size, out_size, adj_lists, device, GNN_layers, num_timestamps):
        super(STGAT, self).__init__()

        # 输入参数初始化
        self.num_timestamps = num_timestamps
        self.input_size = input_size
        self.out_size = out_size
        self.adj_lists = adj_lists
        self.tot_nodes = adj_lists.shape[0]
        self.device = device
        self.GNN_layers = GNN_layers
        self.dim = self.num_timestamps * self.tot_nodes

        # 定义可训练参数
        self.his_temporal_weight = nn.Parameter(torch.FloatTensor(num_timestamps, out_size))
        self.his_final_weight = nn.Parameter(torch.FloatTensor(2 * out_size, out_size))
        self.final_weight = nn.Parameter(torch.FloatTensor(num_timestamps * out_size, num_timestamps * out_size))

        # 隔离后时间衰减干预的可训练参数
        self.theta = nn.Parameter(torch.FloatTensor(1, 1))

        # 初始化粗糙模块和细致模块
        self.Coarse_module = Coarse_module(self.tot_nodes, num_timestamps, input_size, adj_lists)
        self.Fine_module = MultiEffectFusion(input_size, adj_lists, num_timestamps)

        # 参数初始化
        self.init_params()

    def init_params(self):
        ''' 初始化模型参数，使用 Xavier 均匀分布初始化。 '''
        for param in self.parameters():
            if len(param.size()) == 2:
                nn.init.xavier_uniform_(param)

    def forward(self, attributes):
        '''
        前向传播，接收输入特征并在图结构上进行处理。
        attributes: 输入特征，包含历史数据和干预变量，维度为 (batch_size, num_timestamps, features)。
        '''
        # 分离历史特征和干预变量
        his_raw_features = attributes[:, :, :self.input_size]  # 删除时间和干预变量信息
        time_interval = attributes[:, :, self.input_size:(self.input_size + 1)]  # 获取时间间隔数据
        interven = attributes[:, :, (self.input_size + 1):(self.input_size + 2)]  # 获取干预变量

        # 计算干预衰减
        interven_decay = torch.sigmoid(-self.theta * time_interval)
        # 若干预变量为0.5则使用衰减值，否则保持原值
        interven_adjust = torch.where(interven == 0.5, interven_decay, interven)

        # 多层图卷积传播
        for i in range(self.GNN_layers):
            # 调整输入特征的维度
            his_raw_features = his_raw_features.contiguous().view(self.num_timestamps, self.tot_nodes, self.input_size)

            # 计算粗糙和细致的连接矩阵
            coarse_matrix = self.Coarse_module(his_raw_features, interven_adjust)  # NT * NT
            fine_matrix = self.Fine_module(his_raw_features)  # NT * NT

            # 合并加权矩阵
            A_temporal = coarse_matrix * fine_matrix  # 计算最终的ST加权矩阵
            D_temporal = Degree_Matrix(A_temporal)  # 计算节点的度矩阵

            # 调整维度以适配 GConv
            his_raw_features = his_raw_features.contiguous().view(-1, self.input_size)

            # 创建 GConv 实例并前向计算
            GCN = GConv(D_temporal, A_temporal, self.tot_nodes, self.his_temporal_weight, self.his_final_weight)
            his_raw_features = GCN(his_raw_features)

        # 收集历史特征
        his_list = []
        for timestamp in range(self.num_timestamps):
            st = timestamp * self.tot_nodes
            en = (timestamp + 1) * self.tot_nodes
            his_list.append(his_raw_features[st:en, :])

        # 拼接嵌入特征
        his_embds = torch.cat(his_list, dim=1)
        embds = his_embds
        # 应用最后的线性变换和激活函数
        embds = torch.relu(self.final_weight.mm(embds.t()).t())

        return embds


"""
下游任务
"""


class Regression(nn.Module):
    '''
    回归任务层，用于根据嵌入特征输出预测结果。
    '''

    def __init__(self, emb_size, out_size):
        super(Regression, self).__init__()

        # 定义一个简单的全连接层结构
        self.layer = nn.Sequential(
            nn.Linear(emb_size, emb_size),
            nn.ReLU(),
            nn.Linear(emb_size, out_size),
            nn.ReLU()
        )

        # 参数初始化
        self.init_params()

    def init_params(self):
        ''' 将模型参数使用 Xavier 均匀分布初始化。 '''
        for param in self.parameters():
            if len(param.size()) == 2:
                nn.init.xavier_uniform_(param)

    def forward(self, embds):
        '''
        前向传播，将嵌入特征输入到回归层中并输出预测结果。
        embds: 输入的嵌入特征。
        '''
        logists = self.layer(embds)  # 经过全连接层处理
        return logists  # 返回预测结果