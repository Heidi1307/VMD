import torch
import argparse
import random
import numpy as np
from sklearn.metrics import mean_absolute_error
import torch.nn as nn
import torch.nn.functional as F
import configparser

from main_model import *  # 导入模型模块
from utils import *  # 导入工具模块

"""
疾病模型类(DiseaseModel)
该类用于实现一个时空图注意力网络 (ST-GAT) 模型，用于疾病传播预测。
"""


class DiseaseModel:

    def __init__(self, train_data, train_label, val_data, val_label, test_data, test_label,
                 adj, input_size, out_size, GNN_layers, epochs, device, num_timestamps, pred_len,
                 save_flag, PATH, t_debug, b_debug, lr):
        '''
        初始化类，定义模型参数及数据集。

        参数：
        - train_data: 训练数据
        - train_label: 训练标签
        - val_data: 验证数据
        - val_label: 验证标签
        - test_data: 测试数据
        - test_label: 测试标签
        - adj: 邻接矩阵
        - input_size: 输入特征的维度
        - out_size: 输出特征的维度
        - GNN_layers: GNN的层数
        - epochs: 训练的总轮数
        - device: 设备类型（CPU或GPU）
        - num_timestamps: 历史时间戳的数量
        - pred_len: 预测的未来时间戳的数量
        - save_flag: 是否保存模型的标志
        - PATH: 保存路径
        - t_debug: 时间调试标志
        - b_debug: 批调试标志
        - lr: 学习率
        '''
        super(DiseaseModel, self).__init__()

        # 数据和标签的存储
        self.train_data, self.train_label = train_data, train_label
        self.val_data, self.val_label = val_data, val_label
        self.test_data, self.test_label = test_data, test_label
        self.adj = adj

        # 所有节点的索引
        self.all_nodes = [i for i in range(self.adj.shape[0])]

        # 模型参数的初始化
        self.input_size = input_size
        self.out_size = out_size
        self.GNN_layers = GNN_layers
        self.device = device
        self.epochs = epochs
        self.regression = Regression(input_size * num_timestamps, pred_len)  # 回归模型初始化
        self.num_timestamps = num_timestamps
        self.pred_len = pred_len
        self.lr = lr

        self.node_bsz = 512  # 节点批次大小
        self.PATH = PATH
        self.save_flag = save_flag

        # 数据转换为张量并移动到设备
        self.train_data = torch.FloatTensor(self.train_data).to(device)
        self.val_data = torch.FloatTensor(self.val_data).to(device)
        self.test_data = torch.FloatTensor(self.test_data).to(device)
        self.train_label = torch.FloatTensor(self.train_label).to(device)
        self.val_label = torch.FloatTensor(self.val_label).to(device)
        self.test_label = torch.FloatTensor(self.test_label).to(device)
        self.all_nodes = torch.LongTensor(self.all_nodes).to(device)
        self.adj = torch.FloatTensor(self.adj).to(device)

        self.t_debug = t_debug  # 时间调试标志
        self.b_debug = b_debug  # 批调试标志

    def run_model(self):
        '''
        训练模型并评估验证集上的表现。
        '''
        timeStampModel = STGAT(self.input_size, self.out_size, self.adj,
                               self.device, self.GNN_layers, self.num_timestamps)
        timeStampModel.to(self.device)  # 转移模型到GPU/CPU上

        regression = self.regression
        regression.to(self.device)  # 转移回归模型到GPU/CPU上

        # 初始化最佳验证损失和最佳轮数
        self.best_val = float("Inf")
        self.best_epoch = float("Inf")

        self_lr = self.lr  # 复制学习率
        lr = self_lr

        # 存储训练历史数据
        train_loss_his = []
        loss_idx = []
        val_loss_his = []
        RMSE_his = []
        MAE_his = []

        train_loss = torch.tensor(0.).to(self.device)  # 用于储存每轮训练损失的初始值
        for epoch in range(self.epochs):
            print("Epoch: ", epoch, " running...")

            tot_timestamp = len(self.train_data)  # 获取训练数据的总时间戳
            if self.t_debug:
                tot_timestamp = 60  # 调试模式下仅运行前60个时间戳
            idx = np.random.permutation(tot_timestamp)  # 打乱时间戳索引

            for data_timestamp in idx:  # 迭代每个时间戳

                tr_data = self.train_data[data_timestamp]  # 当前时间戳的训练数据
                tr_label = self.train_label[data_timestamp]  # 当前时间戳的训练标签

                # 应用模型进行训练
                timeStampModel, regression, train_loss = apply_model(self.all_nodes, timeStampModel,
                                                                     regression, self.node_bsz, self.device, tr_data,
                                                                     tr_label, train_loss, lr, self.pred_len)

                if self.b_debug:
                    break  # 批调试模式下只运行一次

            train_loss /= len(idx)  # 计算训练损失的平均值

            print("Train avg loss: ", train_loss)

            pred = []  # 存储预测结果
            label = []  # 存储真实标签
            tot_timestamp = len(self.val_data)  # 获取验证数据的总时间戳

            if self.t_debug:
                tot_timestamp = 60  # 调试模式下仅运行前60个时间戳

            idx = np.random.permutation(tot_timestamp)  # 打乱验证集索引
            val_loss = torch.tensor(0.).to(self.device)  # 初始化验证损失
            for data_timestamp in idx:

                # val_label
                raw_features = self.val_data[data_timestamp]  # 当前时间戳的验证数据
                val_label = self.val_label[data_timestamp]  # 当前时间戳的验证标签

                # 评估模型
                temp_predicts, val_loss = evaluate(self.all_nodes, raw_features, val_label,
                                                   timeStampModel, regression, val_loss)

                label = label + val_label.detach().tolist()  # 收集验证标签
                pred = pred + temp_predicts.detach().tolist()  # 收集预测结果

                if self.b_debug:
                    break  # 批调试模式下只运行一次

            val_loss /= len(idx)  # 计算验证损失的平均值
            print("Average Validation Loss: ", val_loss)

            # 检查是否更新最佳验证损失
            if epoch > 0 and val_loss < self.best_val:
                self.best_val = val_loss  # 更新最佳验证损失
                self.best_epoch = epoch  # 更新最佳轮数

                if self.save_flag:  # 检查是否需要保存模型
                    torch.save(timeStampModel,
                               self.PATH + "/" + str(self.pred_len) + "day_" + str(
                                   self.GNN_layers) + "layer_bestTmodel.pth")
                    torch.save(regression,
                               self.PATH + "/" + str(self.pred_len) + "day_" + str(
                                   self.GNN_layers) + "layer_bestRegression.pth")

            # 提前停止
            if epoch - self.best_epoch > 30 and val_loss > self.best_val:
                break

            # 计算RMSE和MAE
            RMSE = torch.nn.MSELoss()(torch.FloatTensor(pred), torch.FloatTensor(label))
            RMSE = torch.sqrt(RMSE).item()
            MAE = mean_absolute_error(pred, label)

            # 输出当前最佳验证情况
            print("Min validation loss: ", self.best_val)
            print("Best epoch: ", self.best_epoch)
            print("===============================================")

            # 存储历史结果
            loss_idx.append(epoch)
            train_loss_his.append(train_loss.item())
            val_loss_his.append(val_loss.item())
            RMSE_his.append(RMSE)
            MAE_his.append(MAE)

            # 创建报告
            report = {"epoch": loss_idx,
                      "train_avg_loss": train_loss_his,
                      "val_avg_loss": val_loss_his,
                      "val_RMSE": RMSE_his,
                      "val_MAE": MAE_his}
            report = pd.DataFrame(report)
            print(report)
            print("===============================================")

        return

    def run_Trained_Model(self):
        '''
        使用训练好的模型在测试集上进行预测和评估性能。
        '''
        # 加载最佳的时间戳模型和回归模型
        timeStampModel = torch.load(
            self.PATH + "/" + str(self.pred_len) + "day_" + str(self.GNN_layers) + "layer_bestTmodel.pth")
        regression = torch.load(
            self.PATH + "/" + str(self.pred_len) + "day_" + str(self.GNN_layers) + "layer_bestRegression.pth")

        pred = []  # 存储预测结果
        label = []  # 存储真实标签
        tot_timestamp = len(self.test_data)  # 获取测试数据的总时间戳
        idx = np.random.permutation(tot_timestamp)  # 打乱测试数据索引
        test_loss = torch.tensor(0.).to(self.device)  # 初始化测试损失

        # 遍历测试数据
        for data_timestamp in idx:
            # test_label
            raw_features = self.test_data[data_timestamp]  # 当前时间戳的测试数据
            test_label = self.test_label[data_timestamp]  # 当前时间戳的测试标签

            # 评估模型
            temp_predicts, test_loss = evaluate(self.all_nodes, raw_features, test_label,
                                                timeStampModel, regression, test_loss)

            label = label + test_label.detach().tolist()  # 收集测试标签
            pred = pred + temp_predicts.detach().tolist()  # 收集预测结果

        test_loss /= len(idx)  # 计算测试损失的平均值
        print("Average Test Loss: ", test_loss)

        # 计算RMSE和MAE
        RMSE = torch.nn.MSELoss()(torch.FloatTensor(pred), torch.FloatTensor(label))
        RMSE = torch.sqrt(RMSE).item()
        MAE = mean_absolute_error(pred, label)

        print("Test RMSE: ", RMSE)
        print("Test MAE: ", MAE)
        print("===============================================")

        pred = torch.FloatTensor(pred)  # 转换为张量
        label = torch.FloatTensor(label)  # 转换为张量
        mae = []  # 存储每个时刻的MAE
        rmse = []  # 存储每个时刻的RMSE

        # 对每个预测时刻进行评估
        for t in range(self.pred_len):
            yhat = pred[:, t]  # 当前时刻的预测值
            y = label[:, t]  # 当前时刻的真实值

            rmse_i = torch.nn.MSELoss()(yhat, y)  # 计算单个时刻的RMSE
            rmse_i = torch.sqrt(rmse_i).item()  # 计算平方根
            mae_i = mean_absolute_error(yhat, y)  # 计算单个时刻的MAE

            print("Horizon:", t + 1, ", test rmse:", rmse_i, ", test mae:", mae_i)
            mae.append(mae_i)  # 存储MAE
            rmse.append(rmse_i)  # 存储RMSE

        print("===============================================")

        # 创建报告
        report = {"Best_epoch": self.best_epoch,
                  "Min_val_loss": self.best_val.item(),
                  "Ave_test_loss": test_loss.item(),
                  "Test_RMSE": RMSE,
                  "Test_MAE": MAE}
        report = pd.DataFrame(report, index=[0])

        # 将报告保存为CSV文件
        filename = self.PATH + "/" + str(self.pred_len) + "day_" + str(self.GNN_layers) + "layer.csv"
        report.to_csv(filename, encoding='gbk')

        return


"""
应用模型
该函数负责在一批节点上运行训练，以更新模型参数。
"""


def apply_model(train_nodes, STGAT, regression,
                node_batch_sz, device, train_data, train_label, avg_loss, lr, pred_len):
    '''
    在指定的batch中应用ST-GAT和回归模型，更新参数。

    参数：
    - train_nodes: 训练节点
    - STGAT: ST-GAT模型
    - regression: 回归模型
    - node_batch_sz: 每个batch的节点数量
    - device: 设备（CPU/GPU）
    - train_data: 训练数据
    - train_label: 训练标签
    - avg_loss: 平均损失（用于记录）
    - lr: 学习率
    - pred_len: 预测长度
    '''

    models = [STGAT, regression]  # 模型列表
    params = []
    for model in models:
        for param in model.parameters():
            if param.requires_grad:  # 获取需要训练的参数
                params.append(param)

    # 使用Adam优化器
    optimizer = torch.optim.Adam(params, lr=lr, weight_decay=0)

    optimizer.zero_grad()  # 重置梯度
    for model in models:
        model.zero_grad()  # 重置每个模型的梯度

    node_batches = math.ceil(len(train_nodes) / node_batch_sz)  # 计算节点batch的数量

    loss = torch.tensor(0.).to(device)  # 初始化损失
    raw_features = train_data  # 原始数据
    labels = train_label  # 原始标签

    # 遍历节点批次
    for index in range(node_batches):
        nodes_batch = train_nodes[index * node_batch_sz:(index + 1) * node_batch_sz]  # 当前节点batch
        nodes_batch = nodes_batch.view(nodes_batch.shape[0], 1)  # 调整形状
        labels_batch = labels[nodes_batch]  # 获取当前batch的标签
        labels_batch = labels_batch.view(len(labels_batch), pred_len)  # 调整形状

        # 计算节点的嵌入
        embs_batch = STGAT(raw_features)

        logists = regression(embs_batch)  # 回归预测
        loss_sup = torch.nn.MSELoss()(logists, labels_batch)  # 计算MSE损失
        loss_sup /= len(nodes_batch)  # 平均损失
        loss += loss_sup  # 累积损失

    avg_loss += loss.item()  # 更新平均损失

    loss.backward()  # 反向传播
    for model in models:
        nn.utils.clip_grad_norm_(model.parameters(), 5)  # 梯度裁剪，防止梯度爆炸
    optimizer.step()  # 更新参数

    # 重置优化器
    optimizer.zero_grad()
    for model in models:
        model.zero_grad()

    return STGAT, regression, avg_loss


"""# 训练"""

# 数据集路径
DATASET = "../Data/JSOffshore/JSOffshore_feature"

# 读取配置文件
config_file = './{}.conf'.format(DATASET)
config = configparser.ConfigParser()
config.read(config_file)

# 解析命令行参数
parser = argparse.ArgumentParser(description='pytorch version of DASTGN')
parser.add_argument('-f')  # 交互式输入支持

# 数据路径、邻接矩阵、保存路径等参数
parser.add_argument('--feature_path', type=str, default=config['data']['feature_path'], help='data path')
parser.add_argument('--adj_path', type=str, default=config['data']['adj_path'], help='adjacency matrix')
parser.add_argument('--save_path', type=str, default=config['data']['save_path'], help='save path')

# 模型参数
parser.add_argument('--input_size', type=int, default=config['model']['input_size'], help='size of the input features')
parser.add_argument('--out_size', type=int, default=config['model']['out_size'], help='size of the output features')
parser.add_argument('--interven_start', type=int, default=config['model']['interven_start'],
                    help='the time index of quarantine started')
parser.add_argument('--interven_end', type=int, default=config['model']['interven_end'],
                    help='the time index of quarantine ended')
parser.add_argument('--num_timestamps', type=int, default=config['model']['num_timestamps'],
                    help='number of historical timestamps')
parser.add_argument('--pred_len', type=int, default=config['model']['pred_len'],
                    help='number of future timestamps for prediction')
parser.add_argument('--GNN_layers', type=int, default=config['model']['GNN_layers'], help='number of ST-GAT layers')

# 训练参数
parser.add_argument("--lr", type=float, default=config['train']['lr'], help="learning rate")
parser.add_argument("--epochs", type=int, default=config['train']['epochs'], help="maximum epochs")
parser.add_argument("--seed", type=int, default=config['train']['seed'], help="random seed")

# CUDA设备选择
parser.add_argument('--cuda', action='store_true', help='use CUDA')
parser.add_argument('--trained_model', action='store_true')  # 是否使用已训练的模型
parser.add_argument('--save_model', action='store_true', default=True)  # 是否保存模型

args = parser.parse_args()  # 解析参数

# 设置设备
device = torch.device("cuda:0" if args.cuda and torch.cuda.is_available() else "cpu")
print('DEVICE:', device)

"""
主函数
"""
print('JSOffshore Forecasting based on DASTGN')

# 设置随机种子以确保结果可重复
random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed_all(args.seed)

# 数据加载
data_loader = DataLoader(args.adj_path, args.feature_path, args.num_timestamps, args.pred_len, args.interven_start,
                         args.interven_end, args.seed)
train_data, train_label, val_data, val_label, test_data, test_label, adj = data_loader.split_data()  # 划分数据集

# 设置标志
save_flag = True
t_debug = False
b_debug = False

# 创建疾病模型实例
hModel = DiseaseModel(train_data, train_label, val_data, val_label, test_data, test_label, adj, args.input_size,
                      args.out_size, args.GNN_layers, args.epochs, device, args.num_timestamps, args.pred_len,
                      save_flag,
                      args.save_path, t_debug, b_debug, args.lr)

hModel.run_model()  # 训练模型并评估
hModel.run_Trained_Model()  # 使用训练好的模型进行预测和评估