# 导入必要的库
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import *  # 假设utils中包含了自定义的有用函数
import time


class TimeEffect(nn.Module):
    def __init__(self, node_hid_size, out_size, num_timestamps, adj):
        """
        Time-specific effect: Compute the fixed spatial dependency of each specific time slice.
        计算每个特定时间片的固定空间依赖关系。

        参数：
        - node_hid_size: 节点隐藏层的大小，即输入特征维度。
        - out_size: GRU的隐藏状态大小。
        - num_timestamps: 时间戳的数量。
        - adj: 邻接矩阵，表示节点之间的连接关系。
        """
        super(TimeEffect, self).__init__()

        # 初始化GRU层
        self.gru = nn.GRU(input_size=node_hid_size, hidden_size=out_size, batch_first=True)

        self.adj = adj  # 存储邻接矩阵
        self.num_timestamps = num_timestamps  # 存储时间戳数量
        self.tot_nodes = adj.shape[0]  # 获取节点数量
        self.dim = self.num_timestamps * self.tot_nodes  # 计算总维度
        self.input_size = node_hid_size  # 存储输入特征维度

    def forward(self, raw_features):
        """
        前向传播方法。

        参数：
        - raw_features: 输入的原始特征，形状为(时间戳, 节点数, 特征数)。

        返回：
        - ST_weights: 计算得出的时空权重矩阵，维度为(NT * NT, NT * NT)。
        """
        # 根据时间戳的维度，交换 raw_features 的维度
        node_features = raw_features.transpose(0, 1)
        # 通过 GRU 计算输出和隐藏状态
        temp_out, temp_hid = self.gru(node_features)

        # 再次进行维度转换以计算空间权重
        temp = temp_out.transpose(0, 1)
        # 计算节点之间的空间得分
        spatial_scores = torch.matmul(temp, temp.transpose(1, 2).contiguous()) / math.sqrt(self.input_size)
        # 应用Sigmoid激活函数获取空间权重
        spatial_weights = torch.sigmoid(spatial_scores)

        # 构建时空权重矩阵
        ST_weights = spatial_weights.repeat(self.num_timestamps, 1, 1)
        ST_weights = ST_weights.view(self.num_timestamps, self.num_timestamps, self.tot_nodes, self.tot_nodes)
        ST_weights = ST_weights.permute(0, 2, 1, 3)  # 受每个历史时间片的固定空间依赖性的影响
        ST_weights = ST_weights.reshape(self.dim, self.dim)  # 重塑形状为(NT * NT, NT * NT)

        return ST_weights


class GAT(nn.Module):
    def __init__(self, input_size):
        """
        Space-specific effect: Compute the fixed temporal weights at each specific region.
        计算每个特定区域的固定时间权重。

        参数：
        - input_size: 输入特征的维度。
        """
        super(GAT, self).__init__()

        self.input_size = input_size  # 存储输入特征维度

    def forward(self, input, adj):
        """
        前向传播方法。

        参数：
        - input: 输入特征，形状为(批量大小, 节点数, 特征数)。
        - adj: 邻接矩阵，表示节点之间的连接关系。

        返回：
        - out_hid: 应用GAT后的输出特征。
        """
        # 计算空间得分
        spatial_scores = torch.matmul(input, input.transpose(1, 2)) / math.sqrt(self.input_size)
        # 构造零向量用于遮蔽
        zero_vec = -1e12 * torch.ones_like(spatial_scores)
        # 根据邻接矩阵应用遮蔽
        attention = torch.where(adj > 0, spatial_scores, zero_vec)
        # 应用软最大化得到注意力权重
        attention = F.softmax(attention, dim=2)
        # 根据注意力权重计算输出
        out_hid = torch.matmul(attention, input)

        return out_hid


class SpaceEffect(nn.Module):
    def __init__(self, node_input_size, adj, num_timestamps):
        """
        该类整合了时空权重的空间效应。

        参数：
        - node_input_size: 输入节点的特征维度。
        - adj: 邻接矩阵。
        - num_timestamps: 时间戳的数量。
        """
        super(SpaceEffect, self).__init__()

        self.gat = GAT(node_input_size)  # 初始化GAT层

        self.adj = adj  # 存储邻接矩阵
        self.num_timestamps = num_timestamps  # 存储时间戳数量
        self.tot_nodes = adj.shape[0]  # 获取节点数量
        self.dim = self.num_timestamps * self.tot_nodes  # 计算总维度
        self.input_size = node_input_size  # 存储输入特征维度

    def forward(self, raw_features):
        """
        前向传播方法。

        参数：
        - raw_features: 输入的原始特征，形状为(时间戳, 节点数, 特征数)。

        返回：
        - ST_weights: 计算得出的时空权重矩阵，维度为(NT * NT, NT * NT)。
        """
        # 通过GAT获取节点特征
        node_features = self.gat(raw_features, self.adj)

        # 计算时间依赖性
        spatial_features = node_features.transpose(0, 1)
        temp_scores = torch.matmul(spatial_features, spatial_features.transpose(1, 2).contiguous()) / math.sqrt(
            self.input_size)
        spatial_weights = torch.sigmoid(temp_scores)

        # 构建时空权重矩阵
        ST_weights = spatial_weights.repeat(self.tot_nodes, 1, 1)
        ST_weights = ST_weights.view(self.tot_nodes, self.tot_nodes, self.num_timestamps, self.num_timestamps)
        ST_weights = ST_weights.permute(3, 1, 2, 0)  # 受自我区域时间依赖性的影响
        ST_weights = ST_weights.reshape(self.dim, self.dim)  # 重塑形状为(NT * NT, NT * NT)

        return ST_weights


class DirectEffect(nn.Module):
    def __init__(self, input_size, adj, num_timestamps):
        """
        Direct interaction effect: directly compute the weight between any two space-time points.
        直接计算任意两个时空点之间的权值。

        参数：
        - input_size: 输入的特征维度。
        - adj: 邻接矩阵。
        - num_timestamps: 时间戳数量。
        """
        super(DirectEffect, self).__init__()

        self.adj = adj  # 存储邻接矩阵
        self.num_timestamps = num_timestamps  # 存储时间戳数量
        self.tot_nodes = adj.shape[0]  # 获取节点数量
        self.input_size = input_size  # 存储输入特征维度

    def forward(self, raw_features):
        """
        前向传播方法。

        参数：
        - raw_features: 输入的原始特征，形状为(时间戳, 节点数, 特征数)。

        返回：
        - st_scores: 计算得出的时空权重矩阵，维度为(NT * N, NT * N)。
        """
        # 将输入特征展开
        node_features = raw_features.view(raw_features.size()[0] * raw_features.size()[1], -1)
        # 计算时空得分
        st_scores = torch.matmul(node_features, node_features.transpose(0, 1).contiguous()) / math.sqrt(self.input_size)
        # 应用sigmoid激活以得到权重
        st_scores = torch.sigmoid(st_scores)

        return st_scores


class MultiEffectFusion(nn.Module):
    def __init__(self, input_size, adj_lists, num_timestamps):
        """
        Integrate three NT*NT dimensional spatio-temporal weight matrices generated by different space-time effects.
        对不同时空效应生成的三个NT*NT维度时空权重矩阵进行融合。

        参数：
        - input_size: 输入特征的维度。
        - adj_lists: 邻接矩阵。
        - num_timestamps: 时间戳数量。
        """
        super(MultiEffectFusion, self).__init__()

        self.input_size = input_size  # 存储输入特征维度
        self.tot_nodes = adj_lists.shape[0]  # 获取节点数量
        self.num_timestamps = num_timestamps  # 存储时间戳数量
        self.adj = adj_lists  # 存储邻接矩阵
        self.dim = num_timestamps * self.tot_nodes  # 计算总维度

        # 初始化三种时空效应
        self.Time = TimeEffect(input_size, input_size, num_timestamps, adj_lists)
        self.Space = SpaceEffect(input_size, adj_lists, num_timestamps)
        self.Direct = DirectEffect(input_size, adj_lists, num_timestamps)

        # 初始化权重参数
        self.TW = nn.Parameter(torch.FloatTensor(1, 1))  # Temporal weight
        self.SW = nn.Parameter(torch.FloatTensor(1, 1))  # Spatial weight
        self.DW = nn.Parameter(torch.FloatTensor(1, 1))  # Direct interaction weight

    def forward(self, his_raw_features):
        """
        前向传播方法。

        参数：
        - his_raw_features: 历史原始特征，维度为(时间戳, 节点数, 特征数)。

        返回：
        - ST_matrix: 融合后的时空权重矩阵。
        """
        # 使用静态过滤器（假设是提前定义好的函数）
        filter = Static_full(self.tot_nodes, self.num_timestamps, self.adj)

        # 计算每种效应的时空权重矩阵
        temporal_matrix = self.Time(his_raw_features) * filter
        temporal_gate = self.TW * temporal_matrix

        spatial_matrix = self.Space(his_raw_features) * filter
        spatial_gate = self.SW * spatial_matrix

        direct_matrix = self.Direct(his_raw_features) * filter
        direct_gate = self.DW * direct_matrix

        # 将三者的权重进行拼接
        gates = torch.cat((temporal_gate.unsqueeze(0), spatial_gate.unsqueeze(0), direct_gate.unsqueeze(0)), 0)
        # 应用softmax获取权重分配
        gates = F.softmax(gates, dim=0)

        # 计算最终的时空权重矩阵
        ST_matrix = gates[0, :, :] * temporal_matrix + gates[1, :, :] * spatial_matrix + gates[2, :, :] * direct_matrix

        return ST_matrix
