# 导入PyTorch及其子模块
# import torch
import torch.nn as nn
# import torch.nn.functional as F
from utils import *

'''
构造时空相邻块/时空依赖结构
A general function to construct space-time neighboring blocks / space-time dependency structures
'''


def Static(n, t, A, rho_IT, rho_CT1, rho_CT2):
    """
    该函数生成一个时空依赖结构矩阵。
    This function generates a space-time dependency structure matrix.

    :param n: 空间邻接矩阵的维度，表示节点的数量 (dimension of the spatial adjacency matrix)
    :param t: 时间段的长度 (length of periods)
    :param A: 空间邻接矩阵 (spatial adjacency matrix)
    :param rho_IT: 当前状态的可训练参数，表示相邻节点的影响程度 (trainable parameter of the current states of neighbors)
    :param rho_CT1: 自身历史状态的可训练参数 (trainable parameter of the historical states of self)
    :param rho_CT2: 邻居历史状态的可训练参数 (trainable parameter of the historical states of neighbors)
    :return: 返回时空依赖结构矩阵 (a space-time dependency structure matrix)
    """
    # 创建单位矩阵I_S（空间维度）和I_T（时间维度），用于后续的Kronecker(克罗内克)积计算
    I_S = torch.diag_embed(torch.ones(n))
    I_T = torch.diag_embed(torch.ones(t))

    # 将给定的邻接矩阵A赋值给C_S，C_T表示时间依赖的下三角矩阵
    C_S = A
    C_T = torch.tril(torch.ones(t, t), diagonal=-1)

    # 计算时空依赖矩阵A_ST，使用Kronecker积组合不同的依赖
    A_ST = kronecker(rho_IT * I_T, C_S) + kronecker(rho_CT1 * C_T, I_S) + kronecker(rho_CT2 * C_T, C_S)
    # 原备选方案注释掉，保持代码整洁
    # A_ST = rho_CT1 * kronecker(C_T, I_S) + rho_CT2 * kronecker(C_T, C_S) + rho_IT * kronecker(I_T, C_S)

    return A_ST


'''
基于干预的粗粒度模块
Coarse-grained module based on interventions
'''


class STNB_layer(nn.Module):
    # 返回每种类型的时空相邻块的NT * NT维度权重矩阵
    # return NT * NT dimensional weight matrix for each type of space-time neighbor blocks
    def __init__(self, tot_nodes, num_timestamps, input_size, adj_sum):
        """
        初始化STNB层，创建必要的可训练参数和网络结构。
        Initializes the STNB layer, creating necessary trainable parameters and network structure.

        :param tot_nodes: 总节点数量 (total number of nodes)
        :param num_timestamps: 时间戳数量 (number of timestamps)
        :param input_size: 输入特征的维度 (dimension of input features)
        :param adj_sum: 邻接矩阵的和，用于判断干预量是否超过阈值 (sum of adjacency matrix, used to judge if intervention exceeds threshold)
        """
        super(STNB_layer, self).__init__()
        self.dim = tot_nodes * num_timestamps  # 计算总的维度
        self.judge = adj_sum * num_timestamps  # 计算干预判断的阈值

        # 初始化可训练权重，初始值为1
        self.w1 = nn.Parameter(torch.FloatTensor(1, 1))
        self.w2 = nn.Parameter(torch.FloatTensor(1, 1))
        # 创建一个线性层和Sigmoid激活的序列
        self.gate = nn.Sequential(nn.Linear(input_size, 1), nn.Sigmoid())

    def forward(self, features, interven, block_matrix):
        """
        前向传播函数，计算对时空块的加权。
        Forward function to compute the weighted effect of space-time blocks.

        :param features: 输入特征 (input features)
        :param interven: 干预输入 (intervention input)
        :param block_matrix: 时空相邻块矩阵 (space-time neighboring block matrix)
        :return: 计算得到的加权矩阵 (computed weighted matrix)
        """
        # 处理干预，计算块矩阵的总和
        block_sum = torch.sum(block_matrix)
        if block_sum > self.judge:
            # 如果块和超过阈值，计算累积历史干预
            interven_cum = torch.cumsum(interven, dim=0) - interven  # cumulative historical interventions
            interven_adjust = interven_cum.squeeze().view(self.dim, 1)  # 调整后的干预
        else:
            interven_adjust = interven.squeeze().view(self.dim, 1)  # 当前干预

        # 通过块矩阵与特征的矩阵乘法计算信息
        Infor = torch.mm(block_matrix, features)
        # 计算最终特征，包括当前特征和干预的影响
        feat = self.w1 * Infor + interven_adjust.repeat(1, 3) + self.w2 * features

        # 使用门控机制计算权重r
        rho = self.gate(feat)
        # 同一块中的所有冲击点的权重相同
        block_weight = torch.mul(rho.repeat(1, self.dim), block_matrix)

        return block_weight


class Coarse_module(nn.Module):
    # 返回三种时空相邻块的NT * NT维权矩阵
    # return NT * NT dimensional weight matrix of three types of space-time neighbor blocks
    def __init__(self, tot_nodes, num_timestamps, input_size, adj):
        """
        初始化粗粒度模块，创建三个STNB层，分别处理当前状态、自身历史状态和邻居历史状态。
        Initializes the coarse module, creating three STNB layers for the current state, self historical state, and neighbor historical state.

        :param tot_nodes: 总节点数量 (total number of nodes)
        :param num_timestamps: 时间戳数量 (number of timestamps)
        :param input_size: 输入特征的维度 (dimension of input features)
        :param adj: 空间邻接矩阵 (spatial adjacency matrix)
        """
        super(Coarse_module, self).__init__()
        self.tot_nodes = tot_nodes
        self.num_timestamps = num_timestamps
        self.adj = adj
        self.adj_sum = torch.sum(self.adj)  # 计算邻接矩阵的和
        self.input_size = input_size

        # 创建三个STNB层用于不同类型的空间-时间块
        self.Gate_IT = STNB_layer(self.tot_nodes, num_timestamps, input_size, self.adj_sum)  # 当前状态
        self.Gate_CS = STNB_layer(self.tot_nodes, num_timestamps, input_size, self.adj_sum)  # 自身历史状态
        self.Gate_CT = STNB_layer(self.tot_nodes, num_timestamps, input_size, self.adj_sum)  # 邻居历史状态

    def forward(self, his_raw_features, interven):
        """
        前向传播函数，计算三种空间-时间邻接块的综合效果。
        Forward function to compute the combined effect of three types of space-time neighbor blocks.

        :param his_raw_features: 输入的历史特征 (input historical features)
        :param interven: 输入的干预 (input interventions)
        :return: 返回综合的权重矩阵 (returns the combined weight matrix)
        """
        features = his_raw_features.contiguous().view(-1, self.input_size)  # 变换特征形状方便处理

        # 生成三种不同类型的时空依赖结构矩阵
        A_IT = Static(self.tot_nodes, self.num_timestamps, self.adj, rho_IT=1, rho_CT1=0, rho_CT2=0)  # 当前状态
        A_CS = Static(self.tot_nodes, self.num_timestamps, self.adj, rho_IT=0, rho_CT1=1, rho_CT2=0)  # 自身历史状态
        A_CT = Static(self.tot_nodes, self.num_timestamps, self.adj, rho_IT=0, rho_CT1=0, rho_CT2=1)  # 邻居历史状态

        # 计算每种类型的块权重
        gate_IT = self.Gate_IT(features, interven, A_IT)
        gate_CS = self.Gate_CS(features, interven, A_CS)
        gate_CT = self.Gate_CT(features, interven, A_CT)

        # 返回三种权重的总和
        gate = gate_IT + gate_CS + gate_CT

        return gate