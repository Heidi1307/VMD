import torch
import torch.nn as nn
import torch.nn.functional as F

# 生成长期稳定的静态邻接矩阵
class StaticGraphGeneration(nn.Module):
    def __init__(self, num_nodes, embedding_dim):
        super(StaticGraphGeneration, self).__init__()
        # 初始化节点嵌入
        self.Es = nn.Parameter(torch.randn(num_nodes, embedding_dim))  # 源节点嵌入
        self.Et = nn.Parameter(torch.randn(num_nodes, embedding_dim))  # 目标节点嵌入

    def forward(self):
        # 计算源节点与目标节点嵌入的相似度
        As = F.relu(torch.matmul(self.Es, self.Et.T))  # 计算节点间相似性
        As = F.softmax(As, dim=-1)  # 归一化生成静态邻接矩阵
        return As

# 通过时间序列输入和自注意力机制生成动态图
class DynamicGraphGeneration(nn.Module):
    def __init__(self, num_nodes, embedding_dim, time_window, num_heads):
        super(DynamicGraphGeneration, self).__init__()
        # 动态节点嵌入
        self.Ed = nn.Parameter(torch.randn(num_nodes, embedding_dim))
        self.fc = nn.Linear(time_window, embedding_dim)
        self.gru = nn.GRU(embedding_dim, embedding_dim, batch_first=True)
        self.num_heads = num_heads
        self.Wq = nn.Linear(embedding_dim, embedding_dim * num_heads)
        self.Wk = nn.Linear(embedding_dim, embedding_dim * num_heads)

    def forward(self, X):
        # 输入 X 的维度为 (batch_size, num_nodes, time_window)
        # 时间序列与嵌入结合
        X = self.fc(X)  # 将时间序列维度转化为嵌入维度
        Xp, _ = self.gru(X)  # GRU 融合动态输入和节点嵌入

        # 生成动态图的多头自注意力
        Q = self.Wq(Xp)  # 生成查询向量 Q
        K = self.Wk(Xp)  # 生成键向量 K
        Q = Q.view(-1, self.num_heads, Q.size(-2), Q.size(-1) // self.num_heads)
        K = K.view(-1, self.num_heads, K.size(-2), K.size(-1) // self.num_heads)

        # 计算注意力得分并生成动态邻接矩阵
        attention_scores = torch.einsum('bhid,bhjd->bhij', Q, K) / (K.size(-1) ** 0.5)
        Ad = F.softmax(F.relu(attention_scores), dim=-1)  # 生成动态邻接矩阵
        return Ad.mean(dim=1)  # 多头注意力机制的结果融合

# 融合静态和动态邻接矩阵
class GraphFusion(nn.Module):
    def __init__(self, beta=0.95):
        super(GraphFusion, self).__init__()
        self.beta = beta  # 融合系数

    def forward(self, As, Ad):
        # 矩阵融合机制，将静态图和动态图结合
        At = (1 - self.beta) * As + self.beta * Ad
        return At

# 整合静态图、动态图和融合模块，生成最终的最优动态图结构
class DASTGN(nn.Module):
    def __init__(self, num_nodes, embedding_dim, time_window, num_heads, beta=0.95):
        super(DASTGN, self).__init__()
        self.static_graph_gen = StaticGraphGeneration(num_nodes, embedding_dim)
        self.dynamic_graph_gen = DynamicGraphGeneration(num_nodes, embedding_dim, time_window, num_heads)
        self.graph_fusion = GraphFusion(beta)

    def forward(self, X):
        # X 是输入的时间序列数据，形状为 (batch_size, num_nodes, time_window)
        As = self.static_graph_gen()  # 生成静态邻接矩阵
        Ad = self.dynamic_graph_gen(X)  # 生成动态图邻接矩阵
        At = self.graph_fusion(As, Ad)  # 融合生成最终图结构

        # 返回最优动态图 At
        return At

num_nodes = 120  # 节点数量
embedding_dim = 10  # 节点嵌入维度
time_window = 12  # 时间窗口长度
num_heads = 4  # 注意力头数
beta = 0.95  # 融合系数

# 实例化模型
model = DASTGN(num_nodes, embedding_dim, time_window, num_heads, beta)

# 假设输入时间序列数据 X，形状为 (batch_size, num_nodes, time_window)
X = torch.randn(32, num_nodes, time_window)  # 32 是 batch_size

# 前向传播
At = model(X)

# 输出动态邻接矩阵 At
print(At.shape)  # 输出应为 (num_nodes, num_nodes)
