import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import torch


# 假设您的CSV文件每列表示一个节点的风速数据
def load_and_preprocess_data(file_path, time_window):
    # 加载数据
    df = pd.read_csv(file_path)

    # 只保留风速数据（假设 u-wind 和 v-wind 已合成为风速大小）
    data = df.values

    # 数据标准化（可以使用均值-方差标准化）
    scaler = StandardScaler()
    data_scaled = scaler.fit_transform(data)

    # 将数据切分为时间窗口的序列
    sequences = []
    for i in range(len(data_scaled) - time_window):
        sequences.append(data_scaled[i:i + time_window])

    # 转换为 PyTorch tensor
    sequences = np.array(sequences)
    sequences = torch.tensor(sequences, dtype=torch.float32)

    return sequences, scaler


# 调用预处理函数
file_path = 'C:/HeidiExp/projects/demo_0921/Data/NWP_feature/NWP_feature.csv'   # 你的数据集路径

time_window = 12  # 设置时间窗口（每个序列包含12个时间步）
sequences, scaler = load_and_preprocess_data(file_path, time_window)

# 打印预处理后的数据形状
print(sequences.shape)  # 形状为 (样本数, 时间步数, 节点数)
