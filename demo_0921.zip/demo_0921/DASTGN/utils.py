import os
import torch
import numpy as np
import pandas as pd

"""
数据加载器类
负责加载和预处理时间序列数据，用于模型的训练和评估。
"""


class DataLoader:

    def __init__(self, adj_path, stfeature_path, num_timestamps, pred_len, interven_start, interven_end, seed):
        # 初始化路径、时间戳、预测长度和干预区间。

        super(DataLoader, self).__init__()

        self.adj_path = adj_path  # 邻接矩阵的路径。
        self.stfeature_path = stfeature_path  # 空间-时间特征的路径。

        self.num_timestamps = num_timestamps  # 训练时输入的时间步数量。
        self.pred_len = pred_len  # 预测时间步的长度。
        self.seed = seed  # 随机种子，用于可重复性。

        self.interven_start = interven_start  # 干预期的开始索引。
        self.interven_end = interven_end  # 干预期的结束索引。

    def load_data(self):
        # 从指定路径加载动态特征和邻接矩阵。

        # 列出目录中所有的特征文件。
        stfeature_files = os.listdir(self.stfeature_path)

        stfeature = []  # 初始化一个列表，用于存储所有文件的特征。

        # 遍历每个文件以读取数据并准备时间戳/干预标志。
        for i in range(len(stfeature_files)):
            df = pd.read_csv(self.stfeature_path + "/" + stfeature_files[i])
            df['time_interval'] = [i + 1 - self.interven_end] * len(df)  # 为每个数据框添加时间戳。

            # 根据定义的时期分配干预标志。
            df['interven'] = 0  # 在干预期之前默认为0。
            if i >= (self.interven_start - 1) and i < (self.interven_end - 1):
                df['interven'] = 1  # 在干预期标记为1。
            elif i >= (self.interven_end - 1):
                df['interven'] = 0.5  # 在干预期之后标记为0.5。

            stfeature.append(df.values)  # 将特征值附加到列表中。

        Attr = np.array(stfeature)  # 将列表转换为NumPy数组。
        Attr = Attr.astype(np.float32)  # 转换为float32以与PyTorch兼容。

        # 特征标准化以标准化输入数据。
        infect = Attr[:, :, :1]  # 提取感染数据。
        time = Attr[:, :, (Attr.shape[2] - 2):(Attr.shape[2] - 1)]  # 提取时间数据。
        interven = Attr[:, :, (Attr.shape[2] - 1):(Attr.shape[2])]  # 提取干预标志。
        X = Attr[:, :, 1:(Attr.shape[2] - 2)]  # 提取特征数据。

        # 标准化特征数据X。
        means = np.mean(X, axis=(0, 1))  # 计算节点和时间的均值。
        X = X - means.reshape(1, 1, -1)  # 数据中心化。
        stds = np.std(X, axis=(0, 1))  # 计算标准差。
        stds[stds <= 10e-5] = 10e-5  # 设置下限以防止除以零。
        X = X / stds.reshape(1, 1, -1)  # 数据缩放。

        # 将所有处理后的组件合并为最终的数据结构。
        data = np.concatenate((infect, X, time, interven), axis=2)

        # 加载邻接矩阵。
        A = pd.read_csv(self.adj_path).values

        return A, data  # 返回邻接矩阵和标准化后的数据。

    def generate_dataset(self, data):
        """
        通过在时间序列数据上滑动窗口生成数据集样本。

        :type data: ndarray
        :param data: 节点特征，形状为(num_vertices, num_features, num_timesteps)
        :return: 返回一个元组：
            - feat_torch: 输入特征的张量，形状为(num_samples, num_timestamps, num_vertices, num_features)
            - target_torch: 目标值的张量，形状为(num_samples, num_vertices, pred_len)
        """
        # 创建用于滑动窗口采样的索引。
        indices = [(i, i + (self.num_timestamps + self.pred_len)) for i in
                   range(data.shape[0] - (self.num_timestamps + self.pred_len) + 1)]

        features, target = [], []  # 初始化列表以保存特征和目标。
        for i, j in indices:
            features.append(data[i: i + self.num_timestamps, :, :])  # 附加历史特征。
            pred = data[i + self.num_timestamps: j, :, 0].transpose(1, 0)  # 提取预测目标，转置以兼容形状。
            target.append(pred)  # 附加目标预测。

        # 将列表转换为PyTorch可用的张量。
        feat_torch = torch.from_numpy(np.array(features))
        target_torch = torch.from_numpy(np.array(target))

        return feat_torch, target_torch  # 返回特征和目标张量。

    def split_data(self):
        """
        将数据分割为训练、验证和测试集。

        :return: 返回一个元组，包含训练输入、训练目标、验证输入、
                 验证目标、测试输入、测试目标和邻接矩阵。
        """
        adj, X = self.load_data()  # 加载数据和邻接矩阵。

        # 定义训练和验证的分隔线。
        split_line1 = int(X.shape[0] * 0.8)  # 80%用于训练。

        # 将数据划分为训练、验证和测试数据集。
        train_original_data = X[:split_line1, :, :]
        val_original_data = X[split_line1:, :, :]  # 验证数据集也充当测试数据集。
        test_original_data = X[split_line1:, :, :]

        # 根据分割生成输入和输出数据集。
        training_input, training_target = self.generate_dataset(train_original_data)
        val_input, val_target = self.generate_dataset(val_original_data)
        test_input, test_target = self.generate_dataset(test_original_data)

        return training_input, training_target, val_input, val_target, test_input, test_target, adj  # 返回所有数据集。


"""
评估函数
这些函数负责在测试期间评估模型性能及优化参数。
"""


def evaluate(test_nodes, raw_features, labels, DASTGN, regression, test_loss):
    models = [DASTGN, regression]  # 待评估的模型列表。

    params = []  # 用于保存模型参数的列表，以进行梯度冻结。
    for model in models:
        for param in model.parameters():
            if param.requires_grad:  # 检查参数是否需要梯度。
                param.requires_grad = False  # 冻结梯度，避免在评估期间更新权重。
                params.append(param)  # 添加到冻结参数列表中。

    val_nodes = test_nodes  # 保存用于评估的验证节点。
    embs = DASTGN(raw_features)  # 使用DASTGN模型获取嵌入。
    predicts = regression(embs)  # 使用回归模型生成预测。

    # 使用均方误差（MSE）计算监督损失。
    loss_sup = torch.nn.MSELoss()(predicts, labels)
    loss_sup /= len(val_nodes)  # 在验证节点数量上平均损失。
    test_loss += loss_sup.item()  # 记录损失以进行跟踪。

    for param in params:
        param.requires_grad = True  # 在评估后解冻参数。

    return predicts, test_loss  # 返回预测值和更新后的损失。


"""
构建用于USTGCN的时空邻接矩阵
"""


def Static_full(n, t, A):
    """
    使用指定的维度和空间矩阵构建完整的时空邻接矩阵。

    :param n: 空间邻接矩阵的维度（节点数量）。
    :param t: 时间段的长度（时间维度）。
    :param A: 空间邻接矩阵。
    :return: 完整的USTGCN时空邻接矩阵。
    """
    I_S = torch.diag_embed(torch.ones(n))  # 用于空间连接的单位矩阵。
    I_T = torch.diag_embed(torch.ones(t))  # 用于时间连接的单位矩阵。

    C_S = A  # 设置空间邻接矩阵。
    C_T = torch.tril(torch.ones(t, t), diagonal=-1)  # 用于时间连接的下三角矩阵。

    S = I_S + C_S  # 将单位矩阵与空间连接组合。
    A_ST = kronecker(C_T, S) + kronecker(I_T, C_S)  # 使用Kronecker积构建完整邻接矩阵。

    return A_ST  # 返回构造的时空邻接矩阵。


"""
Kronecker积函数
用于构建空间和时间连接的邻接矩阵。
"""


def kronecker(A, B):
    """
    使用Kronecker积构建空间-时间邻接块的邻接矩阵。

    :param A: 时间邻接矩阵。
    :param B: 空间邻接矩阵。
    :return: 形成单个空间-时间块的结果邻接矩阵。
    """
    AB = torch.einsum("ab,cd->acbd", A, B)  # 使用爱因斯坦求和计算张量积。
    AB = AB.contiguous().view(A.size(0) * B.size(0), A.size(1) * B.size(1))  # 重塑结果张量的形状。
    return AB  # 返回重塑后的邻接矩阵。


'''
从时空矩阵构建度矩阵
用于推导度规范化表示。
'''


def Degree_Matrix(ST_matrix):
    """
    根据时空邻接矩阵构建度矩阵。

    :param ST_matrix: 用于计算度矩阵的时空邻接矩阵。
    :return: 形状为(dim, dim)的度矩阵。
    """
    row_sum = torch.sum(ST_matrix, 0)  # 计算每行的总和。

    dim = len(ST_matrix)  # 确定矩阵的维度。
    D_matrix = torch.zeros(dim, dim)  # 初始化度矩阵。
    for i in range(dim):
        D_matrix[i, i] = 1 / max(torch.sqrt(row_sum[i]), 1)  # 计算归一化的度值。

    return D_matrix  # 返回构建的度矩阵。